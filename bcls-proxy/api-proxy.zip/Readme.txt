Installation

1. Unzip to any directory
2. In that directory, run: [sudo] npm install
3. In the same directory, run: node api-proxy.js  (or nodemon api-proxy.js if you have nodemon)